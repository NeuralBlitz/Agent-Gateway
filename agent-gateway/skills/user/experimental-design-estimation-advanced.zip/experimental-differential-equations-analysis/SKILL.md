# Experimental Differential Equations Analysis Skill

## Overview
This skill enables analysis in the domain of differential-equations (mathematics). It represents advanced-level expertise and is designed for production use in research, industry, and educational contexts.

## Description
Use this skill when you need to perform analysis operations related to differential-equations. This includes tasks such as:
- analyze functions
- find eigenvalues
- compute derivatives

The skill leverages numerical methods and follows best practices established in the mathematics community.

## Trigger Conditions
This skill should be activated when:
1. The user explicitly requests analysis in the context of differential-equations
2. The task requires advanced-level understanding of mathematics principles
3. The output needs to be numerical approximations
4. The work involves differential-equations methodologies or techniques

## Key Capabilities
- **Domain Expertise**: Deep understanding of differential-equations principles and methods
- **Practical Application**: Ability to apply analysis techniques to real-world problems
- **Quality Assurance**: Validation and verification of results using mathematics standards
- **Tool Proficiency**: Effective use of proof assistants
- **Documentation**: Clear explanation of methods, assumptions, and limitations

## Usage Guidelines
1. **Input Requirements**: Clearly specify the problem parameters and constraints
2. **Methodology**: Follow established differential-equations protocols and best practices
3. **Validation**: Verify results against known benchmarks or theoretical predictions
4. **Documentation**: Provide comprehensive explanations of all steps and decisions
5. **Iteration**: Refine approach based on intermediate results and feedback

## Output Format
The skill produces analytical solutions in standardized formats appropriate for mathematics applications. Outputs include:
- Detailed technical analysis
- Numerical results with uncertainty quantification
- Visualizations and diagrams where appropriate
- References to relevant literature and methods
- Recommendations for further investigation

## Limitations
- Requires appropriate input data quality and completeness
- Results are subject to assumptions stated in the methodology
- May require validation through independent methods
- Complexity increases with problem scale and dimensionality
- Domain-specific constraints may limit applicability

## Related Skills
Consider combining this skill with:
- Adjacent differential-equations skills for comprehensive analysis
- Complementary mathematics methodologies
- Cross-disciplinary approaches when applicable

## Best Practices
1. Always validate inputs before processing
2. Document all assumptions explicitly
3. Use appropriate error checking and handling
4. Compare results with theoretical expectations
5. Maintain reproducibility through clear documentation
6. Consider computational efficiency for large-scale problems
7. Stay current with differential-equations literature and methods

## Version Information
- Complexity Level: advanced
- Domain: mathematics
- Subdiscipline: differential-equations
- Skill Type: analysis
- Last Updated: 2025
