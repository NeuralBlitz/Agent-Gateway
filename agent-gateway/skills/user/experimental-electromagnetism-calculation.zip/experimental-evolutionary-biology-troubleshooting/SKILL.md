# Experimental Evolutionary Biology Troubleshooting Skill

## Overview
This skill enables troubleshooting in the domain of evolutionary-biology (biology). It represents advanced-level expertise and is designed for production use in research, industry, and educational contexts.

## Description
Use this skill when you need to perform troubleshooting operations related to evolutionary-biology. This includes tasks such as:
- classify organisms
- model populations
- study interactions

The skill leverages bioinformatics pipelines and follows best practices established in the biology community.

## Trigger Conditions
This skill should be activated when:
1. The user explicitly requests troubleshooting in the context of evolutionary-biology
2. The task requires advanced-level understanding of biology principles
3. The output needs to be biological insights
4. The work involves evolutionary-biology methodologies or techniques

## Key Capabilities
- **Domain Expertise**: Deep understanding of evolutionary-biology principles and methods
- **Practical Application**: Ability to apply troubleshooting techniques to real-world problems
- **Quality Assurance**: Validation and verification of results using biology standards
- **Tool Proficiency**: Effective use of microscopy
- **Documentation**: Clear explanation of methods, assumptions, and limitations

## Usage Guidelines
1. **Input Requirements**: Clearly specify the problem parameters and constraints
2. **Methodology**: Follow established evolutionary-biology protocols and best practices
3. **Validation**: Verify results against known benchmarks or theoretical predictions
4. **Documentation**: Provide comprehensive explanations of all steps and decisions
5. **Iteration**: Refine approach based on intermediate results and feedback

## Output Format
The skill produces genetic data in standardized formats appropriate for biology applications. Outputs include:
- Detailed technical analysis
- Numerical results with uncertainty quantification
- Visualizations and diagrams where appropriate
- References to relevant literature and methods
- Recommendations for further investigation

## Limitations
- Requires appropriate input data quality and completeness
- Results are subject to assumptions stated in the methodology
- May require validation through independent methods
- Complexity increases with problem scale and dimensionality
- Domain-specific constraints may limit applicability

## Related Skills
Consider combining this skill with:
- Adjacent evolutionary-biology skills for comprehensive analysis
- Complementary biology methodologies
- Cross-disciplinary approaches when applicable

## Best Practices
1. Always validate inputs before processing
2. Document all assumptions explicitly
3. Use appropriate error checking and handling
4. Compare results with theoretical expectations
5. Maintain reproducibility through clear documentation
6. Consider computational efficiency for large-scale problems
7. Stay current with evolutionary-biology literature and methods

## Version Information
- Complexity Level: advanced
- Domain: biology
- Subdiscipline: evolutionary-biology
- Skill Type: troubleshooting
- Last Updated: 2025
