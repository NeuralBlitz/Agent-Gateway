# Experimental Exoplanet Science Modeling Skill

## Overview
This skill enables modeling in the domain of exoplanet-science (astronomy). It represents expert-level expertise and is designed for production use in research, industry, and educational contexts.

## Description
Use this skill when you need to perform modeling operations related to exoplanet-science. This includes tasks such as:
- analyze spectra
- observe objects
- analyze spectra

The skill leverages telescopes and follows best practices established in the astronomy community.

## Trigger Conditions
This skill should be activated when:
1. The user explicitly requests modeling in the context of exoplanet-science
2. The task requires expert-level understanding of astronomy principles
3. The output needs to be astronomical data
4. The work involves exoplanet-science methodologies or techniques

## Key Capabilities
- **Domain Expertise**: Deep understanding of exoplanet-science principles and methods
- **Practical Application**: Ability to apply modeling techniques to real-world problems
- **Quality Assurance**: Validation and verification of results using astronomy standards
- **Tool Proficiency**: Effective use of orbital mechanics tools
- **Documentation**: Clear explanation of methods, assumptions, and limitations

## Usage Guidelines
1. **Input Requirements**: Clearly specify the problem parameters and constraints
2. **Methodology**: Follow established exoplanet-science protocols and best practices
3. **Validation**: Verify results against known benchmarks or theoretical predictions
4. **Documentation**: Provide comprehensive explanations of all steps and decisions
5. **Iteration**: Refine approach based on intermediate results and feedback

## Output Format
The skill produces astronomical data in standardized formats appropriate for astronomy applications. Outputs include:
- Detailed technical analysis
- Numerical results with uncertainty quantification
- Visualizations and diagrams where appropriate
- References to relevant literature and methods
- Recommendations for further investigation

## Limitations
- Requires appropriate input data quality and completeness
- Results are subject to assumptions stated in the methodology
- May require validation through independent methods
- Complexity increases with problem scale and dimensionality
- Domain-specific constraints may limit applicability

## Related Skills
Consider combining this skill with:
- Adjacent exoplanet-science skills for comprehensive analysis
- Complementary astronomy methodologies
- Cross-disciplinary approaches when applicable

## Best Practices
1. Always validate inputs before processing
2. Document all assumptions explicitly
3. Use appropriate error checking and handling
4. Compare results with theoretical expectations
5. Maintain reproducibility through clear documentation
6. Consider computational efficiency for large-scale problems
7. Stay current with exoplanet-science literature and methods

## Version Information
- Complexity Level: expert
- Domain: astronomy
- Subdiscipline: exoplanet-science
- Skill Type: modeling
- Last Updated: 2025
