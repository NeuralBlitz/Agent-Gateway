# Experimental Geomagnetism Implementation Skill

## Overview
This skill enables implementation in the domain of geomagnetism (earth-sciences). It represents advanced-level expertise and is designed for production use in research, industry, and educational contexts.

## Description
Use this skill when you need to perform implementation operations related to geomagnetism. This includes tasks such as:
- analyze samples
- interpret data
- interpret data

The skill leverages remote sensing and follows best practices established in the earth-sciences community.

## Trigger Conditions
This skill should be activated when:
1. The user explicitly requests implementation in the context of geomagnetism
2. The task requires advanced-level understanding of earth-sciences principles
3. The output needs to be climate models
4. The work involves geomagnetism methodologies or techniques

## Key Capabilities
- **Domain Expertise**: Deep understanding of geomagnetism principles and methods
- **Practical Application**: Ability to apply implementation techniques to real-world problems
- **Quality Assurance**: Validation and verification of results using earth-sciences standards
- **Tool Proficiency**: Effective use of field instruments
- **Documentation**: Clear explanation of methods, assumptions, and limitations

## Usage Guidelines
1. **Input Requirements**: Clearly specify the problem parameters and constraints
2. **Methodology**: Follow established geomagnetism protocols and best practices
3. **Validation**: Verify results against known benchmarks or theoretical predictions
4. **Documentation**: Provide comprehensive explanations of all steps and decisions
5. **Iteration**: Refine approach based on intermediate results and feedback

## Output Format
The skill produces hazard assessments in standardized formats appropriate for earth-sciences applications. Outputs include:
- Detailed technical analysis
- Numerical results with uncertainty quantification
- Visualizations and diagrams where appropriate
- References to relevant literature and methods
- Recommendations for further investigation

## Limitations
- Requires appropriate input data quality and completeness
- Results are subject to assumptions stated in the methodology
- May require validation through independent methods
- Complexity increases with problem scale and dimensionality
- Domain-specific constraints may limit applicability

## Related Skills
Consider combining this skill with:
- Adjacent geomagnetism skills for comprehensive analysis
- Complementary earth-sciences methodologies
- Cross-disciplinary approaches when applicable

## Best Practices
1. Always validate inputs before processing
2. Document all assumptions explicitly
3. Use appropriate error checking and handling
4. Compare results with theoretical expectations
5. Maintain reproducibility through clear documentation
6. Consider computational efficiency for large-scale problems
7. Stay current with geomagnetism literature and methods

## Version Information
- Complexity Level: advanced
- Domain: earth-sciences
- Subdiscipline: geomagnetism
- Skill Type: implementation
- Last Updated: 2025
