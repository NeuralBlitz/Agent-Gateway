# Experimental Geophysics Simulation Skill

## Overview
This skill enables simulation in the domain of geophysics (physics). It represents research-level-level expertise and is designed for production use in research, industry, and educational contexts.

## Description
Use this skill when you need to perform simulation operations related to geophysics. This includes tasks such as:
- predict behavior
- model systems
- model systems

The skill leverages computational models and follows best practices established in the physics community.

## Trigger Conditions
This skill should be activated when:
1. The user explicitly requests simulation in the context of geophysics
2. The task requires research-level-level understanding of physics principles
3. The output needs to be physical predictions
4. The work involves geophysics methodologies or techniques

## Key Capabilities
- **Domain Expertise**: Deep understanding of geophysics principles and methods
- **Practical Application**: Ability to apply simulation techniques to real-world problems
- **Quality Assurance**: Validation and verification of results using physics standards
- **Tool Proficiency**: Effective use of computational models
- **Documentation**: Clear explanation of methods, assumptions, and limitations

## Usage Guidelines
1. **Input Requirements**: Clearly specify the problem parameters and constraints
2. **Methodology**: Follow established geophysics protocols and best practices
3. **Validation**: Verify results against known benchmarks or theoretical predictions
4. **Documentation**: Provide comprehensive explanations of all steps and decisions
5. **Iteration**: Refine approach based on intermediate results and feedback

## Output Format
The skill produces theoretical models in standardized formats appropriate for physics applications. Outputs include:
- Detailed technical analysis
- Numerical results with uncertainty quantification
- Visualizations and diagrams where appropriate
- References to relevant literature and methods
- Recommendations for further investigation

## Limitations
- Requires appropriate input data quality and completeness
- Results are subject to assumptions stated in the methodology
- May require validation through independent methods
- Complexity increases with problem scale and dimensionality
- Domain-specific constraints may limit applicability

## Related Skills
Consider combining this skill with:
- Adjacent geophysics skills for comprehensive analysis
- Complementary physics methodologies
- Cross-disciplinary approaches when applicable

## Best Practices
1. Always validate inputs before processing
2. Document all assumptions explicitly
3. Use appropriate error checking and handling
4. Compare results with theoretical expectations
5. Maintain reproducibility through clear documentation
6. Consider computational efficiency for large-scale problems
7. Stay current with geophysics literature and methods

## Version Information
- Complexity Level: research-level
- Domain: physics
- Subdiscipline: geophysics
- Skill Type: simulation
- Last Updated: 2025
